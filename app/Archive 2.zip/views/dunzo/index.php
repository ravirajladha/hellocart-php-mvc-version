<?php
echo $data;
?>