<html>
  <center> <img src="<?php echo URLROOT; ?>/assets/images/hellow2.gif" alt="" style="margin-top:30%"></center>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>

$(document).ready(function () {      
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    }
});

function showPosition(position) {
  var lat = position.coords.latitude;
  var lon = position.coords.longitude;
  var city;

  var geocodingAPI = "https://maps.googleapis.com/maps/api/geocode/json?latlng="+lat+","+lon+"&key=AIzaSyAVtRoMM1uSg9AXpwG8CBZRCAZO1AGH3JM";

  $.getJSON(geocodingAPI, function (json) {
      if (json.status == "OK") {
          //Check result 0

          var result = json.results[0];
           store_info(result.address_components[2].long_name);
               
      }    
  });

  function store_info(city) {
   $.ajax({
   url  : '<?php echo URLROOT; ?>/ecom/user_location',
   type : 'POST',
   data : {lat,lon,city},

   success : function(res)
   {
      window.location.href = "<?php echo URLROOT; ?>/ecomapp";
      location.assign("<?php echo URLROOT; ?>/ecomapp")
   }

   });
                       
                    
}}
</script>


<!-- 

<button onclick="playAudio();">Click me</button>
<audio id="foobar" src="https://www.learningcontainer.com/wp-content/uploads/2020/02/Kalimba.mp3" preload="auto" style="display: none;">
<script>
    playAudio();
function playAudio() {
var sample = document.getElementById("foobar");
sample.play();
}
</script>

-->


